Ceci est une license de visant a informer et protéger l'oeuvre qui vous est proposé.
Je tient juste a expliquer que pour ceux qui le souhaitent,
il est possible de réutiliser des parties du code du jeux,
en revanche, par respect pour les créateurs du jeux,
merci de ne pas utiliser les images (lettres de l'alphabet exclus) ou la totalité du code.

Ce jeux (même les verison béta) vous sont proposé par Irina Marchand et Henry Letellier
Vous pouvez donner votre avis sur ce formulaire: https://forms.office.com/Pages/ResponsePage.aspx?id=DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAANAAf0m3cRUOUZVQko5VjZXTExTWU41SzBGUkxVSU5ZUy4u