added a scanning in the level (enable you to add a many levels as you wish (juste add 0(and the number of the level)_(the name of your level))
linked the family wolf icon
added it in the level 12
glichted it in the level 11
linked the gardian (the wolf's ennemy)
added hidden levels functions
configures the credit screen
uploaded a certain amount of symbols (but haven't linked them -that is for the next beta file-)
normalised the letters and symbols and other images in the folder alphabet