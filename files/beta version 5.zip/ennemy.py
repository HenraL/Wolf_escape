#here is where the enemy data, (how to place the ennemy, info, where, ...)
#for each level, it will be imported in the main and class files
